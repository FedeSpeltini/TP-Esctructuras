#include "gentree.h"
#include "array_list.h"
//USUARIO
struct GNode
{
  string elem;
  ArrayList children;
};

GenTree leaf(T_ELEM_TYPE x)
{
  /// COMPLETAR
  GNode* t = new GNode;
  t -> elem = x;
  t -> children = crearArrayList();
  return t;
}

bool isLeaf(GenTree t)
{
  /// COMPLETAR
  return length(t -> children) == 0;
}

T_ELEM_TYPE value(GenTree t)
{
     /// COMPLETAR
  return (t ->elem);
}

ArrayList children(GenTree t)
{
     /// COMPLETAR
  return (t -> children);
}

void addChild(GenTree t, GenTree child)
{
  /// COMPLETAR
  add(t -> children, child);
}

void destroyTree(GenTree t)
{
  /// COMPLETAR
  int longitud = length(t-> children);
  while(longitud >= 0)
  {
        //GNode* t = new GNode;
      GNode* get = getAt((t-> children), longitud);
     destroyTree(get);
     longitud--;
  }
   destroyArrayList(t->children);
}
